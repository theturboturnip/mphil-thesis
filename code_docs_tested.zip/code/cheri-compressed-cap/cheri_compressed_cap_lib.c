// Include the cheri_compressed_cap.h file with CC_EXPORT_FUNCS defined.
// This will import the 64-bit and 128-bit API definitions, 
// and define the functions as external.
#define CC_EXPORT_FUNCS
#include "cheri_compressed_cap.h"