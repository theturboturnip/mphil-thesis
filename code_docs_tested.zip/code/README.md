This folder contains the source code for the software artifacts produced by project 2095J.
It has been anonymised, and in the process had some files removed.
Effort has been made to ensure the programs can still be compiled and run, but the intended purpose of this archive is for examining the source code.

The rust-cheri-compressed-cap source code is included in `./cheri-compressed-cap/test/rust-cheri-compressed-cap`.

The riscv-v-lite emulator source code is included in `./riscv-v-lite/rsim`.

The emulator test program source code is included in `./riscv-v-lite/programs/`.

The modifications to CHERI-Clang that enable CHERI-RVV are included in `./llvm-project/`.

The documentation for the emulator and rust-cheri-compressed-cap are available in `./doc/rsim/index.html` and `./doc/rust_cheri_compressed_cap/index.html`.


The emulator requires [Rust](https://www.rust-lang.org/learn/get-started) and an LLVM-based C compiler (any recent version of Clang should do) to compile.
Once these are installed, enter `./riscv-v-lite/` and run `./test.sh` to run the test programs.
The results file in `./riscv-v-lite/test_results/*.tsv` can then be imported into spreadsheet software to view the results.