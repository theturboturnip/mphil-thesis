(function() {var implementors = {};
implementors["rust_cheri_compressed_cap"] = [];
if (window.register_implementors) {window.register_implementors(implementors);} else {window.pending_implementors = implementors;}})()