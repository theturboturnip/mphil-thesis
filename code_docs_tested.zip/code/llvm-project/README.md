This folder contains the source code files for CHERI-Clang that were modified to add CHERI-RVV support.

It also includes three supplementary files:
- `VECTOR.diff` - The actual diff from CHERI-Clang, which shows exactly which lines were edited or removed.
- `VECTOR.diff.base` - The base commit hash from CHERI-Clang.
- `VECTOR.diff.files` - The list of modified files.

The rest of the source code for CHERI-Clang has not been included, for the sake of file size.
The full CHERI-Clang codebase can be retrieved with the following steps:

```bash
# Get the un-vectorized CHERI-Clang source code
git clone https://github.com/CTSRD-CHERI/llvm-project && cd ./llvm-project/
# Go to the base commit
git checkout $(cat ../VECTOR.diff.base)
# Apply the patch
git apply ../VECTOR.diff
```